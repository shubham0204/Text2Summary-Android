#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

const uint8_t *summarize(const uint8_t *text, uintptr_t length, float reduction_factor);
